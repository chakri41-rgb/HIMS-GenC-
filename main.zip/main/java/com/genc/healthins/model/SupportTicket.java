package com.genc.healthins.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "support_ticket")
public class SupportTicket {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer ticketId;

    @ManyToOne
    @JoinColumn(name = "userId")
    private User user;

    @Lob
    private String issueDescription;

    @Enumerated(EnumType.STRING)
    private TicketStatus ticketStatus;

    private LocalDate createdDate;
    private LocalDate resolvedDate;

    public SupportTicket(){}

    // getters & setters
    public Integer getTicketId(){ return ticketId; }
    public void setTicketId(Integer id){ this.ticketId = id; }

    public User getUser(){ return user; }
    public void setUser(User u){ this.user = u; }

    public String getIssueDescription(){ return issueDescription; }
    public void setIssueDescription(String d){ this.issueDescription = d; }

    public TicketStatus getTicketStatus(){ return ticketStatus; }
    public void setTicketStatus(TicketStatus s){ this.ticketStatus = s; }

    public LocalDate getCreatedDate(){ return createdDate; }
    public void setCreatedDate(LocalDate d){ this.createdDate = d; }

    public LocalDate getResolvedDate(){ return resolvedDate; }
    public void setResolvedDate(LocalDate d){ this.resolvedDate = d; }
}
