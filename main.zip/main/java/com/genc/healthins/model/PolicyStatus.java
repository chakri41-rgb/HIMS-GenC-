package com.genc.healthins.model;
public enum PolicyStatus { ACTIVE, INACTIVE, RENEWED }
