package com.genc.healthins.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "claim")
public class Claim {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer claimId;

    @ManyToOne
    @JoinColumn(name = "policyId")
    private Policy policy;

    private BigDecimal claimAmount;
    private LocalDate claimDate;

    @Enumerated(EnumType.STRING)
    private ClaimStatus claimStatus;

    private Integer doctorId;

    public Claim(){}

    // getters & setters
    public Integer getClaimId(){ return claimId; }
    public void setClaimId(Integer id){ this.claimId = id; }

    public Policy getPolicy(){ return policy; }
    public void setPolicy(Policy p){ this.policy = p; }

    public BigDecimal getClaimAmount(){ return claimAmount; }
    public void setClaimAmount(BigDecimal a){ this.claimAmount = a; }

    public LocalDate getClaimDate(){ return claimDate; }
    public void setClaimDate(LocalDate d){ this.claimDate = d; }

    public ClaimStatus getClaimStatus(){ return claimStatus; }
    public void setClaimStatus(ClaimStatus s){ this.claimStatus = s; }

    public Integer getDoctorId(){ return doctorId; }
    public void setDoctorId(Integer d){ this.doctorId = d; }
}
