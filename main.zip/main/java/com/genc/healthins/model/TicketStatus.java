package com.genc.healthins.model;
public enum TicketStatus { OPEN, RESOLVED }
