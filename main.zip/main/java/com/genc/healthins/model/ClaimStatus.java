package com.genc.healthins.model;
public enum ClaimStatus { OPEN, APPROVED, REJECTED }
