package com.genc.healthins.model;

public enum Role {
    ADMIN,
    AGENT,
    CUSTOMER
}
