package com.genc.healthins.model;
public enum PaymentStatus { SUCCESS, FAILED, PENDING }
