package com.genc.healthins.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "policy")
public class Policy {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer policyId;

    @Column(nullable=false, unique=true)
    private String policyNumber;

    private String coverageType;
    private BigDecimal coverageAmount;
    private BigDecimal premiumAmount;
    private LocalDate startDate;
    private LocalDate endDate;

    @Enumerated(EnumType.STRING)
    private PolicyStatus policyStatus;

    public Policy(){}

    // getters & setters
    public Integer getPolicyId(){ return policyId; }
    public void setPolicyId(Integer id){ this.policyId = id; }

    public String getPolicyNumber(){ return policyNumber; }
    public void setPolicyNumber(String n){ this.policyNumber = n; }

    public String getCoverageType(){ return coverageType; }
    public void setCoverageType(String c){ this.coverageType = c; }

    public BigDecimal getCoverageAmount(){ return coverageAmount; }
    public void setCoverageAmount(BigDecimal a){ this.coverageAmount = a; }

    public BigDecimal getPremiumAmount(){ return premiumAmount; }
    public void setPremiumAmount(BigDecimal p){ this.premiumAmount = p; }

    public LocalDate getStartDate(){ return startDate; }
    public void setStartDate(LocalDate d){ this.startDate = d; }

    public LocalDate getEndDate(){ return endDate; }
    public void setEndDate(LocalDate d){ this.endDate = d; }

    public PolicyStatus getPolicyStatus(){ return policyStatus; }
    public void setPolicyStatus(PolicyStatus s){ this.policyStatus = s; }
}
