package com.genc.healthins.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "payment")
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer paymentId;

    @ManyToOne
    @JoinColumn(name = "policyId")
    private Policy policy;

    private BigDecimal paymentAmount;
    private LocalDate paymentDate;

    @Enumerated(EnumType.STRING)
    private PaymentStatus paymentStatus;

    public Payment(){}

    // getters & setters
    public Integer getPaymentId(){ return paymentId; }
    public void setPaymentId(Integer id){ this.paymentId = id; }

    public Policy getPolicy(){ return policy; }
    public void setPolicy(Policy p){ this.policy = p; }

    public BigDecimal getPaymentAmount(){ return paymentAmount; }
    public void setPaymentAmount(BigDecimal a){ this.paymentAmount = a; }

    public LocalDate getPaymentDate(){ return paymentDate; }
    public void setPaymentDate(LocalDate d){ this.paymentDate = d; }

    public PaymentStatus getPaymentStatus(){ return paymentStatus; }
    public void setPaymentStatus(PaymentStatus s){ this.paymentStatus = s; }
}
