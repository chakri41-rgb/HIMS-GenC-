package com.genc.healthins.service;

import com.genc.healthins.model.User;

import java.util.Optional;

public interface AuthService {
    User register(User user);
    Optional<User> findByUsername(String username);
}
