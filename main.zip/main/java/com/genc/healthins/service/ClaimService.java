package com.genc.healthins.service;

import com.genc.healthins.model.Claim;
import java.util.List;
import java.util.Optional;

public interface ClaimService {
    Claim submitClaim(Claim claim);
    Optional<Claim> getClaimById(Integer id);
    Claim updateClaimStatus(Integer id, String status);
    List<Claim> getAllClaims();
}
