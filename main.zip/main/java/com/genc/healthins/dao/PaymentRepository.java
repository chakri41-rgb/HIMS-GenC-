package com.genc.healthins.dao;

import com.genc.healthins.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PaymentRepository extends JpaRepository<Payment, Integer> {
    List<Payment> findByPolicy_PolicyId(Integer policyId);
}
