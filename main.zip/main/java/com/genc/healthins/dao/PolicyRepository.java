package com.genc.healthins.dao;

import com.genc.healthins.model.Policy;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PolicyRepository extends JpaRepository<Policy, Integer> {
    Optional<Policy> findByPolicyNumber(String policyNumber);
}
