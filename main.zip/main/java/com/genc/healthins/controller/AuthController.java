package com.genc.healthins.controller;

import com.genc.healthins.model.User;
import com.genc.healthins.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.security.authentication.*;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired private AuthService authService;
    @Autowired private AuthenticationManager authManager;

    // Register — only CUSTOMER allowed (role set in service)
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user) {
        if(authService.findByUsername(user.getUsername()).isPresent()){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Username already exists");
        }
        User created = authService.register(user);
        created.setPassword(null); // hide password
        return ResponseEntity.ok(created);
    }

    // Login — authenticate and create session
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User loginRequest, HttpSession session) {
        try {
            authManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword())
            );
            // On success, fetch user and put in session
            User u = authService.findByUsername(loginRequest.getUsername()).orElse(null);
            if(u != null) {
                session.setAttribute("user", u);
                u.setPassword(null);
                return ResponseEntity.ok(u);
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
            }
        } catch (BadCredentialsException ex) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }

    // Logout — invalidate session
    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpSession session){
        session.invalidate();
        return ResponseEntity.ok("Logged out");
    }

    // Get current profile from session
    @GetMapping("/profile")
    public ResponseEntity<?> profile(HttpSession session){
        Object obj = session.getAttribute("user");
        if(obj == null) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Not logged in");
        User u = (User)obj;
        u.setPassword(null);
        return ResponseEntity.ok(u);
    }
}
