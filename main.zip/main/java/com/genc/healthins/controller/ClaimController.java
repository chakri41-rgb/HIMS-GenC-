package com.genc.healthins.controller;

import com.genc.healthins.model.Claim;
import com.genc.healthins.service.ClaimService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/claims")
public class ClaimController {

    @Autowired private ClaimService claimService;

    @PostMapping
    public ResponseEntity<?> submitClaim(@RequestBody Claim claim){
        Claim c = claimService.submitClaim(claim);
        return ResponseEntity.status(HttpStatus.CREATED).body(c);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getClaimDetails(@PathVariable Integer id){
        Optional<Claim> opt = claimService.getClaimById(id);
        return opt.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PreAuthorize("hasAuthority('ADMIN')")
    @PutMapping("/{id}/status")
    public ResponseEntity<?> updateClaimStatus(@PathVariable Integer id, @RequestParam String status){
        Claim c = claimService.updateClaimStatus(id, status);
        if(c == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(c);
    }

    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping
    public ResponseEntity<List<Claim>> getAllClaims(){
        return ResponseEntity.ok(claimService.getAllClaims());
    }
}
