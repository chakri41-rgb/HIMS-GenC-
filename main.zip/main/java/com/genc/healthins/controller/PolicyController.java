package com.genc.healthins.controller;

import com.genc.healthins.model.Policy;
import com.genc.healthins.service.PolicyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/policies")
public class PolicyController {

    @Autowired private PolicyService policyService;

    @PreAuthorize("hasAuthority('ADMIN')")
    @PostMapping
    public ResponseEntity<?> createPolicy(@RequestBody Policy policy){
        Policy p = policyService.createPolicy(policy);
        return ResponseEntity.status(HttpStatus.CREATED).body(p);
    }

    @PreAuthorize("hasAuthority('ADMIN')")
    @PutMapping("/{id}")
    public ResponseEntity<?> updatePolicy(@PathVariable Integer id, @RequestBody Policy policy){
        Policy p = policyService.updatePolicy(id, policy);
        if(p == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(p);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getPolicyById(@PathVariable Integer id){
        Optional<Policy> opt = policyService.getPolicyById(id);
        return opt.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping
    public ResponseEntity<List<Policy>> getAllPolicies(){
        return ResponseEntity.ok(policyService.getAllPolicies());
    }

    @PreAuthorize("hasAuthority('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletePolicy(@PathVariable Integer id){
        policyService.deletePolicy(id);
        return ResponseEntity.ok("Deleted");
    }
}
