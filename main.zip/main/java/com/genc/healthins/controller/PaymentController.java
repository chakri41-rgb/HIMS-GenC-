package com.genc.healthins.controller;

import com.genc.healthins.model.Payment;
import com.genc.healthins.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    @Autowired private PaymentService paymentService;

    @PostMapping
    public ResponseEntity<?> makePayment(@RequestBody Payment payment){
        Payment p = paymentService.makePayment(payment);
        return ResponseEntity.status(HttpStatus.CREATED).body(p);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getPaymentDetails(@PathVariable Integer id){
        Optional<Payment> opt = paymentService.getPaymentById(id);
        return opt.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/policy/{policyId}")
    public ResponseEntity<List<Payment>> getPaymentsByPolicy(@PathVariable Integer policyId){
        return ResponseEntity.ok(paymentService.getPaymentsByPolicy(policyId));
    }

    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping
    public ResponseEntity<List<Payment>> getAllPayments(){
        return ResponseEntity.ok(paymentService.getAllPayments());
    }
}
