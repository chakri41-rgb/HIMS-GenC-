package com.genc.healthins.controller;

import com.genc.healthins.model.SupportTicket;
import com.genc.healthins.service.SupportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/tickets")
public class SupportController {

    @Autowired private SupportService supportService;

    @PostMapping
    public ResponseEntity<?> createTicket(@RequestBody SupportTicket ticket){
        SupportTicket t = supportService.createTicket(ticket);
        return ResponseEntity.status(HttpStatus.CREATED).body(t);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getTicketDetails(@PathVariable Integer id){
        Optional<SupportTicket> opt = supportService.getTicketById(id);
        return opt.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PreAuthorize("hasAuthority('ADMIN')")
    @PutMapping("/{id}/resolve")
    public ResponseEntity<?> resolveTicket(@PathVariable Integer id){
        SupportTicket t = supportService.resolveTicket(id);
        if(t == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(t);
    }

    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping
    public ResponseEntity<List<SupportTicket>> getAllTickets(){
        return ResponseEntity.ok(supportService.getAllTickets());
    }
}
